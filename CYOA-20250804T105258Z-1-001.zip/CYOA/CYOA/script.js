const caixaPrincipal = document.querySelector('.caixa-principal');

const caixaPerguntas = document.querySelector('.caixa-perguntas');

const caixaAlternativas = document.querySelector('.caixa-alternativas');

const caixaResultado = document.querySelector('.caixa-resultado');

const textoResultado = document.querySelector('.texto-resultado');
{}
const lista = [item1, item2]
const lapis = {
tamanho: 20,
tipo: 'HB',
cor: 'Grafite',
temBorrachaAtras: false
}
let atual = 0;
let perguntaAtual;
function mostraPergunta() {
    if (atual >= perguntas.length) {

mostraResultado();
return;

}
perguntaAtual = perguntas[atual];}
function mostraAlternativas() {}
caixaPerguntas.textContent = perguntaAtual.enunciado;
caixaAlternativas.textContent = " ";
for(const alternativa of perguntaAtual.alternativas) {
const botaoAlternativa = document.createElement("button");
botaoAlternativa.textContent = alternativa.texto;
caixaAlternativas.appendChild(botaoAlternativa);
botaoAlternativa.addEventListener("click", function())
mostraAlternativas();}
function mostraResultado() {
caixaPerguntas.textContent = "Em 2049...";
textoResultado.textContent = historiaFinal;
caixaAlternativas.textContent = " ";
function respostaSelecionada(opcaoSelecionada) {
const afirmacoes = opcaoSelecionada.afirmacao;
historiaFinal = afirmacoes;
atual++;
function respostaSelecionada(opcaoSelecionada) {
const afirmacoes = opcaoSelecionada.afirmacao;
historiaFinal += afirmacoes + " ";
atual++;
mostraPergunta();
}
mostraPergunta();
}
}
function mostraAlternativas() {
for(const alternativa of perguntaAtual.alternativas) {
const botaoAlternativa = document.createElement("button");
botaoAlternativa.textContent = alternativa.texto;
botaoAlternativa.addEventListener("click", function() {
atual++;
let historiaFinal = "";
mostraPergunta();
})}
}

mostraPergunta();
const perguntas = [
{
enunciado: "Assim que saiu da escola você se depara com uma nova tecnologia, um chat que consegue responder todas as dúvidas que uma pessoa pode ter, ele também gera imagens e áudios hiper-realistas. Qual o primeiro pensamento?",
 alternativas: [{
texto: "Isso é assustador!",
afirmacao: "afirmacao",
texto:"Isso é maravilhoso!",
afirmação:"afirmação"}
]
},
{enunciado: "você mora ali",
alternativas: [{
texto: "não eu não moro ali",
afirmacao: "afirmacao,",
texto: "eu moro ali",
afirmação: "afirmação",
}]
},

{enunciado: "você mora aqui",
alternativas: [{
texto: "não eu não moro aqui",
afirmacao: "afirmacao,",
texto: "eu moro aqui",
afirmação: "afirmação",
}]
},]
{


}



botaoAlternativas.addEventListener("click", () =>
respostaSelecionada(alternativa));
function respostaSelecionada(opcaoSelecionada) {
atual++;
mostraPergunta();
}
function respostaSelecionada(opcaoSelecionada) {
const afirmacoes = opcaoSelecionada.afirmacao;
historiaFinal = afirmacoes;
atual++;
mostraPergunta();
}